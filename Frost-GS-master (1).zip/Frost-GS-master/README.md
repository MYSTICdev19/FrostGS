![Banner](https://media.discordapp.net/attachments/1012206596769730622/1237002667826610236/frost.png?ex=663a1002&is=6638be82&hm=ae5affb6054c908b8469974bdbbd4552117cc73fde655512b2e07a5d729fe583&=&format=webp&quality=lossless)

**[CLICK HERE FOR THE GAMESERVER LINK](https://gofile.io/d/U8S2MD)**

Project Frost is simply an Exit Universal Gameserver fork from Project Reboot (a very outdated gameserver from half a year ago), Lawinv2/Momentum (plain Momentum with minor adjustments), and the Eon Launcher (beta one from Zinx if I'm not mistaken), using Twin1's autohost.

- Q: You may be asking why their gameserver is on GitHub?
- A: If you're going to use someone's code, respectfully give them credit or create a channel crediting them respectfully or admit your using it without shame. However, Project Frost has decided to hide this information from you guys for some reason, which I can't answer since I'm not a part of it. So, I've decided to open-source it because Zulu (a "developer" of Frost) has claimed it is not the Exit Universal Gameserver, which this source shows differently from his claims.
