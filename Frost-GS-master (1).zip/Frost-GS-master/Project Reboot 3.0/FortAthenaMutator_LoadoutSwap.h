#pragma once

#include "FortAthenaMutator.h"

class AFortAthenaMutator_LoadoutSwap : public AFortAthenaMutator
{
public:
};