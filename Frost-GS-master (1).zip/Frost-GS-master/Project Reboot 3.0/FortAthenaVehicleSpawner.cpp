#include "FortAthenaVehicleSpawner.h"

#include "vehicles.h"

void AFortAthenaVehicleSpawner::SpawnVehicleHook(AFortAthenaVehicleSpawner* VehicleSpawner)
{
	// literally doesnt get called!!!!

	LOG_INFO(LogDev, "omgonmg call!!!!\n\n");
	// SpawnVehicleFromSpawner(VehicleSpawner);
}