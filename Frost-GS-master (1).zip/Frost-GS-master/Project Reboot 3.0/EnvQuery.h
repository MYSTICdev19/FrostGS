#pragma once

#include "Object.h"

class UEnvQuery : public UObject // UDataAsset
{
public:
};