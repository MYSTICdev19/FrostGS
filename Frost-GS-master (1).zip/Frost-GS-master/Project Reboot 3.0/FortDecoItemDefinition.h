#pragma once

#include "FortWeaponItemDefinition.h"

class UFortDecoItemDefinition : public UFortWeaponItemDefinition
{
public:

	static UClass* StaticClass();
};