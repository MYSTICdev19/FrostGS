#pragma once

#include "Object.h"

class ULevelStreaming : public UObject
{
public:
};